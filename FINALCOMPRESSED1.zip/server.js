// --- 1. SETUP ---
// Import necessary packages
const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const path = require('path'); // Used for handling file paths
// Create the Express app
const app = express();

// --- 2. MIDDLEWARE ---
// Middleware are functions that run for every request
app.use(cors()); // Allows your frontend to talk to this backend
app.use(express.json()); // Allows the server to understand incoming JSON data

// This is the crucial line: It tells Express to serve all the static files 
// (index.html, style.css, script.js, models folder) from the 'frontend' directory.
app.use(express.static(path.join(__dirname, 'frontend')));



// --- 3. DATABASE CONNECTION ---
// IMPORTANT: Replace this with your actual connection string from MongoDB Atlas
const uri = "mongodb+srv://23951a66f6:QRattendance@qtrack.rthehqk.mongodb.net/testdb";
const client = new MongoClient(uri);


// --- 4. API ROUTE ---
// This is the endpoint your frontend will send the face data to
// Change this line in server.js:
app.post('/api/register-face', async (req, res) => {
    // Get the data sent from the frontend
    const { studentId, faceDescriptor, confidence, timestamp } = req.body;

    // Validate the incoming data
    if (!studentId || !faceDescriptor) {
        return res.status(400).json({ 
            message: "Invalid data: studentId and faceDescriptor are required." 
        });
    }

    try {
        await client.connect();
        const database = client.db("face-recognition");
        const students = database.collection("students");

        // Store the complete face data
        const faceData = {
            studentId: studentId,
            faceDescriptor: faceDescriptor, // 128-dimensional array
            confidence: confidence,
            registrationDate: timestamp || new Date().toISOString(),
            lastUpdated: new Date().toISOString()
        };

        // Find student by ID and update/create record
        const result = await students.updateOne(
            { studentId: studentId },
            { 
                $set: faceData,
                $setOnInsert: { createdAt: new Date().toISOString() }
            },
            { upsert: true }
        );

        console.log(`Student ${studentId} face data stored successfully.`);
        console.log('Face descriptor length:', faceDescriptor.length);
        
        res.status(201).json({ 
            message: "Face registration successful!",
            studentId: studentId,
            confidence: confidence
        });

    } catch (err) {
        console.error("Database error:", err);
        res.status(500).json({ 
            message: "Database error occurred",
            error: err.message 
        });
    } finally {
        // Close the database connection
        await client.close();
    }
});



// --- 5. START THE SERVER ---
// Define the port number. It will use 3000 unless another port is specified.
const PORT = process.env.PORT || 3000;

// Start listening for requests
app.listen(PORT, () => {
    console.log(`Server is running successfully on http://127.0.0.1:${PORT}`);
});